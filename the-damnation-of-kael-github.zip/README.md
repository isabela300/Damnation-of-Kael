# The Damnation of Kael

A Binding of Isaac–style VR game for Meta Quest, made with three.js and WebXR.

- `index.html` – start page
- `game.html` – the game (VR on Quest, or computer)
- `mobile.html` – phone version with touch controls
- `test.html` – test mode (Test Lab and Item Vault)

Play it online with GitHub Pages: Settings → Pages → Deploy from a branch → `main` / root.
